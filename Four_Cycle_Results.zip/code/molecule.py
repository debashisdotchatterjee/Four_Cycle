"""Generate energy data from deposited NMR terms. Scores receive only binned or raw energies."""
from itertools import product
from pathlib import Path
import hashlib
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from spectral import EDGES, METHODS, energy_scores, cp_interval, summarize, rate_summary

XML_URL = "https://gissmo.bmrb.io/entry/bmse000037/simulation_1/spin_simulation.xml"
XML_SHA = "da2499cf731235ad59dc5b4849cc00973207f720c95d9e792318e0f539bf1192"


def read_spins(xml_path):
    raw = Path(xml_path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != XML_SHA:
        raise ValueError("GISSMO input differs from the pinned record.")
    root = ET.fromstring(raw)
    assert root.findtext('ID') == 'bmse000037' and float(root.findtext('field_strength')) == 499.84
    names = {int(x.get('index')):x.get('name') for x in root.findall('.//spin_names/spin')}
    shifts = sorted((int(x.get('index')),float(x.get('ppm'))) for x in root.findall('.//chemical_shifts_ppm/cs'))
    pairs = [(int(x.get('from_index')),int(x.get('to_index')),float(x.get('value')))
             for x in root.findall('.//couplings_Hz/coupling') if float(x.get('value')) != 0]
    assert len(shifts)==5 and len(pairs)==8
    # (bit-flip mask, Z phase mask, number of Y factors) specifies i^nY X^x Z^z.
    a = np.array([v for _,v in shifts])
    p = (a-a.mean())**2
    p /= p.sum()
    rows = [(0, 1 << (i-1), 0) for i,_ in shifts]
    cols, q, couplings = [], [], []
    for k,l,j in pairs:
        bits = (1 << (k-1)) | (1 << (l-1))
        for op in ['X','Y']:
            cols.append((bits, bits if op=='Y' else 0, 2 if op=='Y' else 0))
            couplings.append((k,l,names[k],names[l],op,j))
            q.append(j*j)
    q = np.asarray(q)/sum(q)
    row_df = pd.DataFrame({'spin_index':[i for i,_ in shifts], 'atom_id':[names[i] for i,_ in shifts],
                           'shift_ppm':a,'row_probability':p})
    col_df = pd.DataFrame(couplings,columns=['spin_k','spin_l','atom_k','atom_l','pauli','coupling_hz'])
    col_df['column_probability'] = q
    return rows, cols, p, q, row_df, col_df


def pair_bit(P,Q):
    return (((P[0] & Q[1]).bit_count() + (P[1] & Q[0]).bit_count()) % 2)


def sign_code(ops):
    return sum(pair_bit(ops[a],ops[b]) << k for k,(a,b) in enumerate(EDGES))


def folded_molecular_law(spec, rows, cols, p, q):
    """Integrate the protocol over 5² x 16² term choices and 32 masks, without using u."""
    original_mass = np.zeros(64)
    for i,ii,j,jj in product(range(len(p)),range(len(p)),range(len(q)),range(len(q))):
        code = sign_code((rows[i],rows[ii],cols[j],cols[jj]))
        original_mass[code] += p[i]*p[ii]*q[j]*q[jj]
    masked_codes = np.arange(64)[:,None] ^ spec.masks
    probs = original_mass @ spec.code_laws[masked_codes].mean(axis=1)
    np.testing.assert_allclose(probs.sum(), 1)
    return probs/probs.sum()


def molecular_shots(rng, spec, rows, cols, p, q, count):
    """Diagonalize a physical orbit of the five-spin + four-auxiliary-qubit Hamiltonian per shot."""
    energies = np.empty(count)
    orbit_bits = np.arange(16)
    for s in range(count):
        i,ii = rng.choice(len(p),2,p=p)
        j,jj = rng.choice(len(q),2,p=q)
        ops = [rows[i],rows[ii],cols[j],cols[jj]]
        mask = int(rng.choice(spec.masks))
        coeff = 2*rng.integers(2,size=4)-1
        tagged = []
        for k,(x,z,ny) in enumerate(ops):
            x |= 1 << (5+k)
            for e,(a,b) in enumerate(EDGES):
                if b==k and mask & (1<<e):
                    z |= 1 << (5+a)
            tagged.append((x,z,ny))
        # Each slot toggles its own auxiliary bit. Every orbit has exactly 16 states.
        # Uniform base state and a uniform eigenvalue in its orbit sample normalized trace.
        basis = np.full(16,rng.integers(512),dtype=int)
        for k,(x,_,_) in enumerate(tagged):
            basis ^= np.where((orbit_bits>>k)&1, x, 0)
        H = np.zeros((16,16))
        for k,(_,z,ny) in enumerate(tagged):
            phase = np.array([(-1)**((int(state)&z).bit_count()+ny//2) for state in basis])
            H[orbit_bits^(1<<k),orbit_bits] = .5*coeff[k]*phase
        assert np.array_equal(H,H.T)
        eig = np.linalg.eigvalsh(H)
        if s < 64:
            np.testing.assert_allclose(eig, spec.bank[sign_code(ops)^mask],atol=1e-12)
        energies[s] = rng.choice(eig)
    return energies


def study_molecule(root, cfg, rng, spec, xml_path):
    rows,cols,p,q,shifts,couplings = read_spins(xml_path)
    shifts.to_csv(root/'data/shifts.csv',index=False)
    couplings.to_csv(root/'data/couplings.csv',index=False)
    probs = folded_molecular_law(spec,rows,cols,p,q)
    energies = molecular_shots(rng,spec,rows,cols,p,q,cfg['physical_shots'])
    pd.DataFrame({'shot':np.arange(1,len(energies)+1),'energy':energies}).to_csv(
        root/'raw/molecular_physical_shots.csv',index=False)
    # The reference is computed independently of the synthetic spectral generator and estimators.
    C = np.array([[1-2*int(i in (k,l)) for k,l in couplings[['spin_k','spin_l']].itertuples(index=False,name=None)]
                  for i in shifts.spin_index])
    K = np.sqrt(p[:,None]*q)*C
    u = np.sum((K @ K.T)**2)
    np.testing.assert_allclose(u, np.sum(np.linalg.svd(K,compute_uv=False)**4))
    np.testing.assert_allclose(probs, spec.law(u),atol=2e-12)
    np.testing.assert_allclose(u, .6244619960496645,atol=2e-12,rtol=0)
    pd.DataFrame({'energy_abs':spec.atoms,'nmr_probability':probs,'nu_minus':spec.minus,
                  'nu_plus':spec.plus,'score_per_shot':spec.scores[:,1]}).to_csv(root/'data/energy_atoms.csv',index=False)
    reference = dict(u=float(u),mean_shift_ppm=float(shifts.shift_ppm.mean()),endpoint_probability=float(probs[spec.endpoint_index]),
                     eighth_moment=float(probs @ spec.atoms**8))
    direct = energy_scores(energies)
    summary, raw, draws = [], {}, cfg['nmr_reps']
    for j,method in enumerate(METHODS):
        pdirect = summarize(direct[:,j],u)
        pdirect.update(method=method,truth=u)
        summary.append(pdirect)
    pd.DataFrame(summary).to_csv(root/'tables/nmr_direct_shots.csv',index=False)
    summary = []
    for T in cfg['nmr_budgets']:
        counts = rng.multinomial(T,probs,size=draws)
        estimates = counts @ spec.scores / T
        lo, hi = cp_interval(counts[:,spec.endpoint_index],T)
        raw['T'+str(T)] = np.column_stack([estimates,lo,hi])
        for j,method in enumerate(METHODS):
            row = summarize(estimates[:,j],u)
            row.update(T=T,method=method,truth=u, theory_variance=float(probs @ (spec.scores[:,j]-u)**2/T))
            if j==0:
                row.update(rate_summary((lo<=u)&(u<=hi)))
            summary.append(row)
    np.savez_compressed(root/'raw/nmr_replicates.npz',**raw)
    results = pd.DataFrame(summary)
    results.to_csv(root/'tables/nmr_performance.csv',index=False)
    return reference,shifts,couplings,C,results
