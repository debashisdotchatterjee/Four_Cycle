"""Direct finite-system moments from a sparse Pauli trace and an independent pairing benchmark."""
from functools import lru_cache
from itertools import combinations, product
from math import prod
import numpy as np
import pandas as pd
from spectral import draw_sign_arrays, summarize
from networks import MODELS


class TraceLayers:
    """Only bitstrings of Hamming weight <=4 are reachable in H^4|0>. Cache their incidence."""
    def __init__(self,N):
        self.layers=[]
        parent_masks=np.array([0],dtype=np.int64)
        for degree in range(1,5):
            vertices=np.array(list(combinations(range(N),degree)),dtype=int).reshape(-1,degree)
            powers=np.left_shift(np.int64(1),vertices)
            masks=powers.sum(axis=1)
            order=masks.argsort()
            vertices,powers,masks=vertices[order],powers[order],masks[order]
            parents=np.searchsorted(parent_masks,(masks[:,None]^powers))
            self.layers.append((vertices,parents,len(parent_masks)))
            parent_masks=masks

    def moments(self,S,weights):
        # Upward and downward amplitudes are transposes of one another by self-adjointness.
        incidences=[]
        for vertices,parents,parent_size in self.layers:
            factors=weights[vertices].copy()
            for k in range(1,vertices.shape[1]):
                for j in range(k):
                    factors[:,k]*=S[vertices[:,j],vertices[:,k]]
            incidences.append((factors,parents,parent_size))
        amplitudes={0:np.ones(1)}
        output=[]
        for step in range(1,5):
            reached={}
            for degree,amplitude in amplitudes.items():
                factors,parents,_=incidences[degree]
                up=(factors*amplitude[parents]).sum(axis=1)
                reached[degree+1]=reached.get(degree+1,0)+up
                if degree>0:
                    factors,parents,size=incidences[degree-1]
                    down=np.bincount(parents.ravel(),weights=(factors*amplitude[:,None]).ravel(),minlength=size)
                    reached[degree-1]=reached.get(degree-1,0)+down
            amplitudes=reached
            if step>=2:
                output.append(sum(a@a for a in amplitudes.values()))
        return np.array(output)


def pairings(points):
    if not points:
        yield ()
        return
    a,*rest=points
    for b in rest:
        for tail in pairings([x for x in rest if x!=b]):
            yield ((a,b),)+tail


def block_words(k):
    """Distinct equality patterns of length 2k with all multiplicities even."""
    seen=set()
    # Partition the k pairs into equal-index classes via restricted growth strings.
    def patterns(x):
        if len(x)==k:
            yield x
        else:
            for t in range(max(x)+2):
                yield from patterns(x+(t,))
    for paired in pairings(list(range(2*k))):
        for partition in patterns((0,)):
            word=[0]*(2*k)
            for (a,b),s in zip(paired,partition):
                word[a]=word[b]=s
            # pairings are ordered by first endpoint, so the labels already follow first appearance.
            seen.add(tuple(word))
    return sorted(seen)


@lru_cache(None)
def diagram_terms(k):
    """Collect multiplicities of block-typed even words whose sign expectation can be nonzero."""
    from collections import Counter
    terms=Counter()
    for word in block_words(k):
        size=max(word)+1
        edges=[(i,j) for i,j in combinations(range(size),2)
               if sum(word[a]==j and word[b]==i for a in range(len(word)) for b in range(a+1,len(word)))%2]
        degree=[sum(v in edge for edge in edges) for v in range(size)]
        for types in product((0,1),repeat=size):
            if any(types[i]==types[j] for i,j in edges):
                continue  # within-family distinct signs have mean zero
            a=types.count(0)
            ka=sum(types[v]==0 for v in word)//2
            row_ok=all(d%2==0 for v,d in enumerate(degree) if types[v]==0)
            both_ok=all(d%2==0 for d in degree)
            terms[a,size-a,ka,len(edges),row_ok,both_ok]+=1
    return terms


def expected_moments(m,n,model,delta,limit=False):
    """Exact annealed finite trace or its graphon limit. Distinct vertices are sampled without collision."""
    out=[]
    for k in (2,3,4):
        total=0.
        for (a,b,ka,edges,row_ok,both_ok),freq in diagram_terms(k).items():
            if model=='Null' and edges: continue
            if model=='Interaction' and not both_ok: continue
            if model=='Row' and not row_ok: continue
            if limit:
                if a+b!=k: continue
                weight=.5**k
            else:
                fall_m=prod(m-t for t in range(a)) if a<=m else 0
                fall_n=prod(n-t for t in range(b)) if b<=n else 0
                weight=fall_m*fall_n/(2*m)**ka/(2*n)**(k-ka)
            total+=freq*weight*delta**edges
        out.append(total)
    return np.array(out)


def sample_system(rng,m,n,model,d):
    C=draw_sign_arrays(rng,(1,m,n),model,d)[0]
    a=rng.integers(0,2,size=(m+n,m+n))
    a=np.triu(2*a-1,1)
    S=a+a.T+np.eye(m+n,dtype=int)
    S[:m,m:]=C
    S[m:,:m]=C.T
    return S


def trace_checks():
    rng=np.random.default_rng(418)
    # Independent dense matrix validation, including nonuniform family weights.
    for m,n in [(2,2),(3,2)]:
        N=m+n
        S=sample_system(rng,m,n,'Interaction',.5)
        c=np.r_[np.full(m,1/np.sqrt(2*m)),np.full(n,1/np.sqrt(2*n))]
        H=np.zeros((2**N,2**N))
        for state in range(2**N):
            for i in range(N):
                phase=prod(S[j,i] for j in range(i) if state&(1<<j))
                H[state^(1<<i),state]=c[i]*phase
        es=np.linalg.eigvalsh(H)
        np.testing.assert_allclose(TraceLayers(N).moments(S,c),[(es**k).mean() for k in (4,6,8)],atol=1e-10)
    # Independent annealed check: enumerate the full 4-vertex sign space under several kernels.
    m=n=2
    layers=TraceLayers(4)
    c=np.ones(4)/2
    edges=list(combinations(range(4),2))
    moments=[]
    patterns=[]
    for bits in product((-1,1),repeat=6):
        S=np.eye(4,dtype=int)
        for (i,j),s in zip(edges,bits): S[i,j]=S[j,i]=s
        patterns.append(bits)
        moments.append(layers.moments(S,c))
    for model,d in [('Null',0),('Interaction',.5),('Row',.75)]:
        prob=np.zeros(64)
        for tags in product((-1,1),repeat=4):
            means=[(0 if i//2==j//2 else (d*tags[i]*tags[j] if model=='Interaction' else d*tags[i]))
                   for i,j in edges]
            prob+=np.prod((1+np.array(patterns)*means)/2,axis=1)/16
        np.testing.assert_allclose(prob @ moments,expected_moments(2,2,model,d),atol=1e-11)
    for model,d in MODELS:
        M4,M6,M8=expected_moments(2,2,model,d,True)
        np.testing.assert_allclose([M4,M6],[2,5+(3*d*d/8 if model=='Row' else 0)])
        if model!='Row': np.testing.assert_allclose(M8,14+d**4/4)


def study_untagged(root,cfg,rng):
    records=[]
    all_raw={}
    for n in cfg['trace_sizes']:
        for aspect in (1,2):
            m=n*aspect
            op=TraceLayers(m+n)
            c=np.r_[np.full(m,1/np.sqrt(2*m)),np.full(n,1/np.sqrt(2*n))]
            for model,d in MODELS:
                finite=expected_moments(m,n,model,d)
                limit=expected_moments(m,n,model,d,True)
                val=np.stack([op.moments(sample_system(rng,m,n,model,d),c) for _ in range(cfg['trace_reps'])])
                all_raw[f'{m}x{n}_{model}_{d:g}']=val
                for k,order in enumerate((4,6,8)):
                    r=summarize(val[:,k],finite[k])
                    r.update(m=m,n=n,model=model,delta=d,order=order,
                             finite_target=finite[k],limit=limit[k],finite_minus_limit=finite[k]-limit[k])
                    records.append(r)
            print(f'  untagged traces completed: {m} x {n}',flush=True)
    out=pd.DataFrame(records)
    out.to_csv(root/'tables/untagged_moments.csv',index=False)
    np.savez_compressed(root/'raw/untagged_traces.npz',**all_raw)
    return out
