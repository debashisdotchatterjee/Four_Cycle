"""Distinct rectangles on one hidden network per replication; all methods share its shot record."""
from itertools import combinations
from math import comb
import numpy as np
import pandas as pd
from scipy.stats import norm
from spectral import (EDGES, METHODS, NULL_V, distinct_rectangle_mean, draw_sign_arrays,
                      energy_scores, multinomial_rows, rate_summary, summarize)

MODELS = [('Null',0.)]+[(model,d) for model in ('Interaction','Row') for d in (.25,.5,.75)]


def rectangle_check(rng):
    for m,n in [(2,2),(3,5),(6,3)]:
        C = 2*rng.integers(2,size=(m,n))-1
        exact = np.mean([C[i,j]*C[k,j]*C[i,l]*C[k,l]
                         for i,k in combinations(range(m),2) for j,l in combinations(range(n),2)])
        np.testing.assert_allclose(distinct_rectangle_mean(C),exact)
        signed = C*(2*rng.integers(2,size=(m,1))-1)*(2*rng.integers(2,size=(1,n))-1)
        np.testing.assert_allclose(distinct_rectangle_mean(signed),exact)


def distinct_draw(rng, size, count):
    i = rng.integers(size,size=count)
    j = rng.integers(size-1,size=count)
    return i, j+(j>=i)


def small_diagonalization(root,cfg,rng,spec):
    """Generate rectangles and actual masked sign patterns, then sample their diagonalized spectra."""
    m,n=6,4
    systems=cfg['small_systems']
    T=cfg['small_shots']
    summary, raw = [], {}
    for model,d in [('Null',0.),('Interaction',.5),('Row',.5)]:
        estimates,truths=[],[]
        for _ in range(systems):
            C=draw_sign_arrays(rng,(1,m,n),model,d)[0]
            a=rng.integers(2,size=(m,m))
            b=rng.integers(2,size=(n,n))
            a=np.triu(a,1)+np.triu(a,1).T
            b=np.triu(b,1)+np.triu(b,1).T
            i,ii=distinct_draw(rng,m,T)
            j,jj=distinct_draw(rng,n,T)
            pattern=a[i,ii]+(b[j,jj]<<5)
            for shift,(row,col) in enumerate([(i,j),(i,jj),(ii,j),(ii,jj)],1):
                pattern |= (C[row,col]<0).astype(int)<<shift
            masked=pattern ^ rng.choice(spec.masks,size=T)
            ys=spec.bank[masked,rng.integers(16,size=T)]
            estimates.append(energy_scores(ys).mean(axis=0))
            truths.append(distinct_rectangle_mean(C))
        estimates=np.array(estimates)
        truths=np.asarray(truths)
        raw[model]=np.column_stack((truths,estimates))
        for k,method in enumerate(METHODS):
            record=summarize(estimates[:,k]-truths,0)
            record.update(model=model,delta=d,T=T,method=method,m=m,n=n,
                          estimand='estimation error relative to realized U_C')
            summary.append(record)
    np.savez_compressed(root/'raw/small_tagged.npz',**raw)
    pd.DataFrame(summary).to_csv(root/'tables/small_tagged.csv',index=False)


def study_networks(root,cfg,rng,spec):
    summaries=[]
    R=cfg['graph_reps']
    crit=norm.ppf(.95)
    for n in cfg['network_sizes']:
        for aspect in (1,2):
            m=aspect*n
            L=comb(m,2)*comb(n,2)
            for model,delta in MODELS:
                truth=delta**4
                # Batching bounds memory. All budgets use the same R independently drawn systems.
                parts=[]
                for offset in range(0,R,96):
                    C=draw_sign_arrays(rng,(min(96,R-offset),m,n),model,delta)
                    parts.append(distinct_rectangle_mean(C))
                realized=np.concatenate(parts)
                laws=spec.law(realized)
                arrays={'U_C':realized}
                for design,design_v in NULL_V.items():
                    for multiple in (.1,1.,10.):
                        T=max(1,round(design_v*L*multiple))
                        counts=multinomial_rows(rng,T,laws)
                        est=counts @ spec.scores/T
                        arrays[f'{design}_{multiple:g}_T{T}']=est
                        for k,method in enumerate(METHODS):
                            row=summarize(est[:,k],truth)
                            row.update(model=model,delta=delta,truth=truth,m=m,n=n,L=L,T=T,
                                       budget_for=design,budget_ratio=multiple,method=method,
                                       U_mean=realized.mean(),U_variance=realized.var(ddof=1))
                            if method in NULL_V:
                                v=NULL_V[method]
                                null_var=1/L+(v-1/L)/T
                                row.update(null_variance=null_var,
                                           **rate_summary(est[:,k]>crit*np.sqrt(null_var)))
                            summaries.append(row)
                name=f'network_{m}x{n}_{model}_{delta:g}.npz'
                np.savez_compressed(root/'raw'/name,**arrays)
            print(f'  network grid completed: {m} x {n}',flush=True)
    ans=pd.DataFrame(summaries)
    ans.to_csv(root/'tables/network_performance.csv',index=False)
    return ans


def fixed_system_coverage(root, cfg, rng):
    """Select one independent array per condition and repeat the entire endpoint experiment."""
    from scipy.stats import binom
    from spectral import cp_interval

    rows, fixed, raw = [], {}, {}
    R = cfg['conditional_reps']
    tail_probability = .025
    for n in cfg['network_sizes']:
        for aspect in (1, 2):
            m = aspect*n
            L = comb(m, 2)*comb(n, 2)
            for model, delta in MODELS:
                C = draw_sign_arrays(rng, (1, m, n), model, delta)[0]
                system_key = f'{m}x{n}_{model}_{delta:g}'
                fixed[system_key] = C
                u = float(distinct_rectangle_mean(C))
                p = (1+u)/512
                for design, v in NULL_V.items():
                    for ratio in (.1, 1., 10.):
                        T = max(1, round(ratio*v*L))
                        counts = rng.binomial(T, p, size=R)
                        raw[f'{system_key}_{design}_{ratio:g}_T{T}'] = counts
                        # Invert the two exact one-sided binomial tests. The upper
                        # bound follows by applying the lower quantile to T - count.
                        low = int(binom.ppf(tail_probability, T, p))
                        high = T - int(binom.ppf(tail_probability, T, 1-p))
                        covered = (low <= counts) & (counts <= high)
                        exact = binom.cdf(high, T, p) - binom.cdf(low-1, T, p)
                        # Verify the count-space inversion using explicit beta interval bounds.
                        lo_u, hi_u = cp_interval(counts[:12], T)
                        np.testing.assert_array_equal(covered[:12], (lo_u <= u) & (u <= hi_u))
                        assert .95-1e-8 <= exact <= 1+1e-12
                        rows.append(dict(m=m, n=n, model=model, delta=delta, U_C=u,
                                         endpoint_p=p, T=T, R=R, budget_for=design,
                                         budget_ratio=ratio, min_covered_count=low,
                                         max_covered_count=high, exact_coverage=exact,
                                         **rate_summary(covered)))
    np.savez_compressed(root/'raw/coverage_systems.npz', **fixed)
    np.savez_compressed(root/'raw/coverage_endpoint_counts.npz', **raw)
    frame = pd.DataFrame(rows)
    frame.to_csv(root/'tables/network_conditional_coverage.csv', index=False)
    return frame
