"""Run the full empirical study or its small smoke profile. Python 3.10+."""
import argparse
import hashlib
import json
import platform
import shutil
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from importlib.metadata import version
import numpy as np
from threadpoolctl import threadpool_limits
from spectral import Spectra, METHODS
from molecule import study_molecule, XML_URL, XML_SHA
from networks import study_networks, small_diagonalization, rectangle_check, fixed_system_coverage
from untagged import study_untagged, trace_checks
from presentation import render, CAPTIONS

HERE=Path(__file__).resolve().parent
SCRIPTS=('spectral.py','molecule.py','networks.py','untagged.py','presentation.py','run_study.py')
SETTINGS={
    'paper': dict(network_sizes=[8,16,32],graph_reps=2000,conditional_reps=2000,nmr_reps=3000,
                  nmr_budgets=[2000,10000,50000,200000],physical_shots=2048,
                  small_systems=350,small_shots=2048,trace_sizes=[3,6,9],trace_reps=128),
    'quick': dict(network_sizes=[6,10],graph_reps=160,conditional_reps=200,nmr_reps=200,
                  nmr_budgets=[1000,5000,20000],physical_shots=128,
                  small_systems=30,small_shots=256,trace_sizes=[3,5],trace_reps=12),
}

RAW_GUIDE="""# Contents of the results archive

## Inputs and estimands
- data/spin_simulation.xml is the archived GISSMO fitted input. data/shifts.csv and data/couplings.csv retain both atom IDs and selection weights. The archived NMR signal has not been interpreted as a tagged energy sample.
- data/reference.json records the reference from the weighted sign matrix. data/energy_atoms.csv records the molecular energy law obtained independently from fitted terms, masks and exact finite spectra. nu_minus and nu_plus are conditional universal laws of the absolute energy.
- The molecular selection draws with replacement. The graphon selection draws distinct rows and distinct columns. U_C denotes the signed average on a realized network; the population target is zero under the null and delta^4 for either alternative. All inference uses untruncated point estimates.

## Replication data
- raw/molecular_physical_shots.csv contains independently simulated signed energy observations from explicit physical Hamiltonian blocks on the fitted five-spin system and four auxiliary qubits. Each observation redraws term indices, auxiliary masks, coefficient signs and the state. Only energy reaches the estimator.
- raw/nmr_replicates.npz has one matrix per T. Columns are endpoint estimate, score estimate, eighth-moment estimate, lower and upper binomial confidence bounds for u (unclipped). Intersecting the interval with the feasible parameter space has identical coverage of the true reference.
- raw/small_tagged.npz has one matrix per model. Columns are realized U_C, endpoint, score, eighth-moment estimates. Four-slot 16-dimensional spectra are diagonalized once for every sign pattern; each shot then draws a rectangle, random mask and eigenvalue.
- raw/network_*.npz has one file per size/model/amplitude. U_C is a vector of independent system truths. Other keys encode the design estimator, multiplier and absolute T; each R-by-3 matrix uses the same three estimator columns as above. All methods at a given budget use the same observations. Budgets share systems but use independent shot records conditionally on them. Each scenario uses new systems. Network p-values or intervals should not be calculated from iid energy shots unconditionally.
- raw/coverage_systems.npz contains one independently drawn and then fixed sign array for each condition. raw/coverage_endpoint_counts.npz contains the independent repeated counts on that same array at each budget. tables/network_conditional_coverage.csv gives their coverage of U_C and the exact binomial acceptance probability for that array.
- raw/untagged_traces.npz stores R-by-3 arrays of exact conditional trace moments of orders 4, 6 and 8. The uncertainty here is between simulated systems. Calculations exploit the signed Pauli representation and contain no finite-shot noise.

## Tables and figures
- tables/nmr_performance.csv: each row compares an estimator to the fixed molecular reference. Theory variance accounts for the molecular energy distribution at its actual reference. Coverage is computed only for the exact Clopper–Pearson endpoint interval.
- tables/network_performance.csv: every array, model, amplitude, T and estimator. Bias is relative to the population target. Variance is empirical across independent systems and includes both noise sources. null_variance is the exact null variance at that size and T, also shown as the benchmark on alternative rows. rate is null size or alternative power at one-sided nominal 5%. The eighth-moment method has no proposed rejection rule and its test columns are empty.
- tables/small_tagged.csv measures error relative to the realized network. tables/nmr_direct_shots.csv summarizes single-shot values; its variance refers to per-shot variation. tables/untagged_moments.csv compares numerical trace means to exact finite ensemble expectations and limits. For the row-only alternative the full pairing formula determines the eighth moment.
- bias_mcse is the Monte Carlo standard error of the reported bias or trace mean. variance_mcse is a plug-in fourth-central-moment approximation. rate_mcse is the binomial Monte Carlo standard error; rate_lo and rate_hi give Wilson 95% Monte Carlo uncertainty for rejection or empirical coverage. These quantify simulation precision.
- figures/ includes vector PDF and 260 dpi PNG versions. Captions are in figures/CAPTIONS.md. tables/*.tex are standalone table environments for a LaTeX manuscript using the booktabs package. The CSVs contain all numerical values.
- config.json, environment.json, SHA256SUMS.txt and code/ provide the seed, simulation settings, runtime versions, file checksums and the exact Python source. From code/: python run_study.py --profile paper --seed 20261124 --xml ../data/spin_simulation.xml (adjust profile/seed to match config.json).
"""


def json_file(path,obj):
    path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(profile='paper',seed=20261124,output_parent=None,xml_path=None):
    start=time.monotonic()
    cfg=dict(SETTINGS[profile],profile=profile,seed=int(seed))
    parent=Path(output_parent or Path.cwd()).resolve()
    parent.mkdir(parents=True,exist_ok=True)
    workspace=Path(tempfile.mkdtemp(prefix='four_cycle_run_',dir=parent))
    root=workspace/'Four_Cycle_Results'
    for sub in ('data','raw','tables','figures','code'):
        (root/sub).mkdir(parents=True,exist_ok=True)
    source=Path(xml_path) if xml_path is not None else HERE/'spin_simulation.xml'
    shutil.copyfile(source,root/'data/spin_simulation.xml')
    for name in SCRIPTS:
        shutil.copyfile(HERE/name,root/'code'/name)
    json_file(root/'config.json',cfg)
    rngs=[np.random.default_rng(s) for s in np.random.SeedSequence(seed).spawn(6)]
    # Separate streams for checks, molecule, direct small systems, large networks, traces, and fixed-array coverage.
    with threadpool_limits(limits=1):
        spec=Spectra()
        rectangle_check(rngs[0])
        trace_checks()
        print('Four-slot spectral laws, distinct rectangles and finite trace benchmarks verified.',flush=True)
        ref,shifts,couplings,C,molecular=study_molecule(root,cfg,rngs[1],spec,source)
        ref.update(record='bmse000037',dataset_doi='10.13018/BMSE000037',xml_source=XML_URL,
                   xml_sha256=XML_SHA,field_mhz=499.84)
        json_file(root/'data/reference.json',ref)
        print(f'Molecular reference {ref["u"]:.9f}; direct spectra and coverage completed.',flush=True)
        small_diagonalization(root,cfg,rngs[2],spec)
        networks=study_networks(root,cfg,rngs[3],spec)
        traces=study_untagged(root,cfg,rngs[4])
        conditional=fixed_system_coverage(root,cfg,rngs[5])
        render(root,cfg,ref,shifts,couplings,C,molecular,networks,traces,conditional)
    assert len(conditional)==len(cfg['network_sizes'])*2*7*6
    expected_graph_rows=len(cfg['network_sizes'])*2*7*6*len(METHODS)
    assert len(networks)==expected_graph_rows and np.isfinite(networks.bias).all()
    assert len(traces)==len(cfg['trace_sizes'])*2*7*3 and np.isfinite(traces['mean']).all()
    assert all((root/'figures'/(stem+'.pdf')).stat().st_size>1000 for stem in
               ['01_molecular_calibration','02_network_inference','03_untagged_moments','04_shot_budget'])
    (root/'RESULTS_README.md').write_text(RAW_GUIDE,encoding='utf8')
    (root/'figures/CAPTIONS.md').write_text(CAPTIONS,encoding='utf8')
    json_file(root/'environment.json',dict(completed_utc=datetime.now(timezone.utc).isoformat(),
              python=platform.python_version(),platform=platform.platform(),
              versions={k:version(k) for k in ['numpy','pandas','scipy','matplotlib','threadpoolctl']},
              elapsed_seconds=round(time.monotonic()-start,2),independent_streams=6,
              network_summary_rows=len(networks),trace_summary_rows=len(traces),fixed_coverage_rows=len(conditional)))
    files=sorted(p for p in root.rglob('*') if p.is_file())
    checksum_file=root/'SHA256SUMS.txt'
    checksum_file.write_text(''.join(f'{sha(f)}  {f.relative_to(root).as_posix()}\n' for f in files))
    archive=workspace/('Four_Cycle_Results.zip' if profile=='paper' else 'Four_Cycle_Results_QUICK.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=4) as z:
        for f in files+[checksum_file]:
            z.write(f,f.relative_to(root))
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None: raise IOError('ZIP verification failed')
    print(f'Completed {profile} profile in {time.monotonic()-start:.1f} seconds. Results: {archive}',flush=True)
    return root,archive


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--profile',choices=SETTINGS,default='paper')
    parser.add_argument('--seed',type=int,default=20261124)
    parser.add_argument('--output',type=Path,default=None)
    parser.add_argument('--xml',type=Path,default=None)
    args=parser.parse_args()
    run(args.profile,args.seed,args.output,args.xml)
