"""Spectra of four tagged involutions and statistics of energy-only observations."""
from itertools import combinations, product
from math import comb
import numpy as np
import pandas as pd
from scipy.stats import beta, norm

EDGES = tuple(combinations(range(4), 2))
INFO = 41 / 360
CUT = (2 + 1 + 1 / np.sqrt(2)) / 2    # interior of the proved gap
METHODS = ("Endpoint", "Score", "Eighth moment")
NULL_V = {"Endpoint": 511., "Score": 1 / INFO}


def spectrum_from_signs(code):
    """B(S)/2 on the 16 computational states. Bit e of code flags an anticommuting pair."""
    basis = np.arange(16)
    matrix = np.zeros((16, 16))
    for k in range(4):
        phase = np.ones(16)
        for edge, (a, b) in enumerate(EDGES):
            if b == k and (code >> edge) & 1:
                phase *= 1 - 2 * ((basis >> a) & 1)
        matrix[basis ^ (1 << k), basis] = phase / 2
    assert np.array_equal(matrix, matrix.T)
    return np.linalg.eigvalsh(matrix)


def energy_scores(energy):
    """Point estimators use only energies. The ideal discrete atoms have a wide numerical margin."""
    energy = np.asarray(energy)
    z = 4 * energy**2
    def near(x):
        return np.isclose(z, x, rtol=0, atol=1e-7)
    h = np.full(z.shape, -1/3.)
    for value, weight in [(0, 13/45), (2, 1/9), (4, 1/3),
                          (4-2*np.sqrt(3), 0), (4+2*np.sqrt(3), 0),
                          (8, 1), (10, 1), (16, 1)]:
        h[near(value)] = weight
    return np.stack((512*(np.abs(energy) > CUT).astype(float)-1,
                     h / INFO, 16*(energy**8 - 263/32)), axis=-1)


def make_masks():
    """32 equiprobable sign masks, given cross products r_a*t_b; fix the redundant first row sign."""
    masks = []
    for ha, hb, r2, t1, t2 in product((0, 1), repeat=5):
        bits = (ha, t1, t2, r2 ^ t1, r2 ^ t2, hb)
        masks.append(sum(bit << i for i, bit in enumerate(bits)))
    return np.array(masks)


class Spectra:
    def __init__(self):
        self.bank = np.stack([spectrum_from_signs(code) for code in range(64)])
        self.masks = make_masks()
        # Cluster by rounded absolute energy only to merge machine-equal eigenvalues.
        # Use an unrounded mean representative for each even-moment calculation.
        values = np.abs(self.bank).ravel()
        _, bins = np.unique(values.round(10), return_inverse=True)
        bins = bins.ravel()
        self.atoms = np.bincount(bins, weights=values) / np.bincount(bins)
        self.code_laws = np.stack([np.bincount(row, minlength=len(self.atoms))/16
                                   for row in bins.reshape(64, 16)])
        parity = np.array([sum((code >> e) & 1 for e in (1,2,3,4)) % 2 for code in range(64)])
        self.minus = self.code_laws[parity == 1].mean(axis=0)
        self.plus = self.code_laws[parity == 0].mean(axis=0)
        self.scores = energy_scores(self.atoms)
        self.endpoint_index = int(np.flatnonzero(self.atoms > CUT).item())
        for sign, probs in [(-1, self.minus), (1, self.plus)]:
            np.testing.assert_allclose(probs @ self.scores, np.repeat(sign, 3), atol=1e-9)
            np.testing.assert_allclose([probs @ self.atoms**k for k in (2,4,6,8)],
                                       [1, 7/4, 29/8, 263/32+sign/16], atol=1e-10)
        neutral = self.law(0.)
        np.testing.assert_allclose(neutral @ self.scores[:, :2]**2, [511., 1/INFO])
        # Validate the six class multiplicities in the manuscript against the eigenvalues.
        score_labels = (13/45, 1/9, 1/3, 0, 1, -1/3)
        for probs, counts in [(self.minus, (32,64,32,128,0,256)),
                              (self.plus,  (58,80,64,128,54,128))]:
            actual = [512*probs[np.isclose(self.scores[:,1]*INFO, value)].sum()
                      for value in score_labels]
            np.testing.assert_array_equal(actual, counts)
        h = (self.plus-self.minus)/(self.plus+self.minus)
        np.testing.assert_allclose(self.scores[:,1]*INFO, h)

    def law(self, u):
        u = np.asarray(u)[..., None]
        if np.any(np.abs(u) > 1+1e-12):
            raise ValueError("Rectangle average is outside [-1,1].")
        u = u.clip(-1, 1)
        return ((1-u)*self.minus + (1+u)*self.plus)/2


def multinomial_rows(rng, totals, probabilities):
    """One exact multinomial count vector per row. Uses int64 and O(atoms) operations per row."""
    probabilities = np.asarray(probabilities)
    residual = np.broadcast_to(totals, probabilities.shape[:-1]).astype(np.int64).copy()
    counts = np.empty(probabilities.shape, dtype=np.int64)
    tail = probabilities[..., ::-1].cumsum(axis=-1)[..., ::-1]
    for k in range(probabilities.shape[-1]-1):
        p = np.divide(probabilities[...,k], tail[...,k], out=np.zeros_like(tail[...,k]),
                      where=tail[...,k] > 0)
        counts[...,k] = rng.binomial(residual, p.clip(0,1))
        residual -= counts[...,k]
    counts[...,-1] = residual
    return counts


def distinct_rectangle_mean(C):
    """Average over DISTINCT rows and columns. Work on the smaller Gram matrix."""
    C = np.asarray(C, dtype=np.int64)
    if C.shape[-2] > C.shape[-1]:
        C = C.swapaxes(-2, -1)
    m, n = C.shape[-2:]
    g = C @ C.swapaxes(-2, -1)
    off_square = (g*g).sum(axis=(-2,-1)) - m*n*n
    return (off_square - m*(m-1)*n) / (4*comb(m,2)*comb(n,2))


def draw_sign_arrays(rng, shape, model, delta):
    repeats, m, n = shape
    rows = 2*rng.integers(2, size=(repeats, m, 1))-1
    cols = 2*rng.integers(2, size=(repeats, 1, n))-1
    mean = {"Null": 0., "Interaction": delta*rows*cols, "Row": delta*rows}[model]
    return 2*(rng.random(shape) < (1+mean)/2).astype(np.int8)-1


def cp_interval(k, T, alpha=.05):
    k = np.asarray(k)
    lo = np.zeros(k.shape)
    hi = np.ones(k.shape)
    nonzero = k > 0
    nonfull = k < T
    lo[nonzero] = beta.ppf(alpha/2, k[nonzero], T-k[nonzero]+1)
    hi[nonfull] = beta.ppf(1-alpha/2, k[nonfull]+1, T-k[nonfull])
    return 512*lo-1, 512*hi-1


def summarize(values, truth):
    """Independent-replication MCSEs. Variance MCSE uses the fourth central sample moment."""
    x = np.asarray(values, dtype=float)
    r = len(x)
    v = x.var(ddof=1)
    squared_error = (x-truth)**2
    m4 = np.mean((x-x.mean())**4)
    return dict(R=r, mean=x.mean(), bias=x.mean()-truth, bias_mcse=np.sqrt(v/r),
                variance=v, variance_mcse=np.sqrt(max(0., (m4-(r-3)/(r-1)*v*v)/r)),
                rmse=np.sqrt(squared_error.mean()))


def rate_summary(flags):
    k, r = int(np.count_nonzero(flags)), len(flags)
    p = k/r
    # Wilson bounds remain informative if every replication gives the same outcome.
    z = norm.ppf(.975)
    den = 1+z*z/r
    center = (p+z*z/(2*r))/den
    radius = z*np.sqrt(p*(1-p)/r+z*z/(4*r*r))/den
    return dict(rate=p, rate_mcse=np.sqrt(p*(1-p)/r), successes=k,
                rate_lo=max(0., center-radius), rate_hi=min(1., center+radius))
