"""Publication figures and LaTeX tables derived from the saved replicate summaries."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter, MaxNLocator
from spectral import METHODS

COL = {'Endpoint':'#ab5227','Score':'#176586','Eighth moment':'#72549a',
       'Null':'#353f49','Interaction':'#187771','Row':'#ad562e'}
MARK = {'Endpoint':'s','Score':'o','Eighth moment':'^','Null':'o','Interaction':'s','Row':'^'}


def style():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.5,'axes.titlesize':11,
                         'axes.titleweight':'bold','axes.labelcolor':'#193144','text.color':'#193144',
                         'axes.spines.top':False,'axes.spines.right':False,
                         'axes.edgecolor':'#a8b3bc','axes.axisbelow':True,'grid.color':'#d8dfe4',
                         'grid.linewidth':.6,'pdf.fonttype':42,'ps.fonttype':42,'savefig.facecolor':'white'})


def save(fig,root,name):
    for ext in ['pdf','png']:
        fig.savefig(root/'figures'/f'{name}.{ext}',dpi=260,bbox_inches='tight',pad_inches=.12)
    plt.close(fig)


def molecule_figure(root,shifts,couplings,C,results):
    fig,axes=plt.subplots(1,2,figsize=(10.2,4.15),gridspec_kw={'width_ratios':[1,1.13]})
    fig.subplots_adjust(wspace=.37,bottom=.24,top=.88)
    ax=axes[0]
    ax.imshow(C[:,::2],cmap=ListedColormap(['#c46b36','#d9eaf0']),vmin=-1,vmax=1,aspect='auto')
    names=[f'{a}–{b}' for a,b in couplings.iloc[::2][['atom_k','atom_l']].itertuples(index=False,name=None)]
    ax.set(xticks=range(len(names)),xticklabels=names,yticks=range(5),yticklabels=shifts.atom_id,
           xlabel='Coupled proton pair (atom IDs)',ylabel='Shift proton (atom ID)')
    ax.tick_params(axis='x',labelrotation=48)
    ax.set_title('a   Commutation signs',loc='left')
    for i in range(5):
        for j,v in enumerate(C[i,::2]):
            ax.text(j,i,'−' if v<0 else '+',ha='center',va='center',color='#40250e' if v<0 else '#264c60')
    ax=axes[1]
    for method in METHODS:
        grp=results[results.method==method].sort_values('T')
        ax.loglog(grp['T'],grp.rmse,marker=MARK[method],color=COL[method],label=method,lw=1.6)
        ax.loglog(grp['T'],np.sqrt(grp.theory_variance),ls=':',color=COL[method],lw=1.3)
    ax.set(xlabel='Energy shots per replication',ylabel='Root mean squared error')
    ax.grid(True,which='major')
    ax.set_title('b   Recovery of the molecular reference',loc='left')
    ax.legend(frameon=False,fontsize=8)
    save(fig,root,'01_molecular_calibration')


def network_figure(root,df,focus):
    fig,axes=plt.subplots(2,2,figsize=(10.3,6.8),sharex='col',sharey='col')
    fig.subplots_adjust(wspace=.29,hspace=.32,top=.88,bottom=.14)
    sample=df[(df.budget_for=='Score')&(df.budget_ratio==1)&df.method.isin(('Endpoint','Score'))]
    for row,aspect in enumerate((1,2)):
        sel=sample[sample.m==aspect*sample.n]
        ax=axes[row,0]
        ax.axhline(.05,ls='--',lw=1,color='#687783')
        for method,shift in [('Endpoint',-.05),('Score',.05)]:
            g=sel[(sel.model=='Null')&(sel.method==method)].sort_values('n')
            xx=np.arange(len(g))+shift
            ax.errorbar(xx,g.rate,yerr=[np.maximum(0,g.rate-g.rate_lo),np.maximum(0,g.rate_hi-g.rate)],label=method,
                        color=COL[method],marker=MARK[method],capsize=2,ms=4,lw=1.3)
            ax.set_xticks(range(len(g)),g.n.astype(str))
        ax.set(ylabel='Null rejection probability',xlabel='Number of columns, n')
        ax.set_title(f'{"ac"[row]}   Size · '+('m = n' if row==0 else 'm = 2n'),loc='left')
        ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=1))
        ax.grid(axis='y')
        ax=axes[row,1]
        for method,offset in [('Endpoint',-.013),('Score',.013)]:
            for model,extra,marker,ls in [('Interaction',-.004,'o','-'),('Row',.004,'^','--')]:
                g=sel[(sel.n==focus)&(sel.model==model)&(sel.method==method)].sort_values('delta')
                ax.errorbar(g.delta+offset+extra,g.rate,yerr=[np.maximum(0,g.rate-g.rate_lo),np.maximum(0,g.rate_hi-g.rate)],
                            color=COL[method],marker=marker,ls=ls,ms=4,capsize=2,lw=1.25)
        ax.axhline(.05,color='#687783',ls=':',lw=1)
        ax.set(xticks=[.25,.5,.75],xlabel='Signal amplitude, δ',ylabel='Rejection probability',ylim=(-.035,1.055))
        ax.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
        ax.grid(axis='y')
        ax.set_title(f'{"bd"[row]}   Power · {aspect*focus} × {focus}',loc='left')
    handles=[Line2D([],[],color=COL[s],lw=3,label=s) for s in METHODS[:2]]
    handles+=[Line2D([],[],color='#4b5154',marker=m,ls=l,label=s) for s,m,l in
              [('Interaction','o','-'),('Row','^','--')]]
    fig.legend(handles=handles,ncol=4,frameon=False,loc='upper center')
    save(fig,root,'02_network_inference')


def budget_figure(root, df, focus):
    """Compare both spectral protocols at their own measurement-to-system crossover."""
    from spectral import NULL_V
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.95), sharey=True)
    fig.subplots_adjust(wspace=.18, top=.78, bottom=.17)
    grid = np.geomspace(.085, 12, 180)
    sample = df[(df.model=='Null') & (df.n==focus) & (df.budget_for==df.method)]
    for letter, (method, v), ax in zip('ab', NULL_V.items(), axes):
        ax.axhline(1, color='#8996a0', lw=.9, ls=':')
        ax.axvline(1, color='#b9c5c8', lw=.8, ls=':')
        for color, mark, aspect, offset in [('#176586','o',1,.96),('#ab5227','s',2,1.04)]:
            g = sample[(sample.method==method) & (sample.m==aspect*focus)].sort_values('T')
            L = int(g.L.iloc[0])
            ax.plot(grid, 1+(1-1/(v*L))/grid, color=color, lw=1.4, alpha=.75)
            ax.errorbar(g['T']/(v*L)*offset, L*g.variance, yerr=1.96*L*g.variance_mcse,
                        fmt=mark, ms=4.3, capsize=3, color=color)
        ax.set(xscale='log', yscale='log', xlabel=r'Shot budget $T/(vL)$',
               xticks=[.1,1,10], xticklabels=['0.1','1','10'])
        ax.set_title(f'{letter}   {method}',loc='left')
        ax.grid(axis='y',which='major')
    axes[0].set_ylabel(r'Scaled null variance $L\,\mathrm{Var}$')
    handles=[Line2D([],[],color=c,marker=mk,label=f'{m} × {focus}') for c,mk,m in
             [('#176586','o',focus),('#ab5227','s',2*focus)]]
    fig.legend(handles=handles,ncol=2,frameon=False,loc='upper center')
    save(fig,root,'04_shot_budget')


def trace_figure(root,df):
    fig,axes=plt.subplots(1,3,figsize=(11.2,3.85))
    fig.subplots_adjust(wspace=.35,bottom=.16,top=.77)
    sel=df[(df.m==df.n)&((df.delta==0)|(df.delta==.75))]
    for ax,(letter,order) in zip(axes,zip('abc',(4,6,8))):
        for model,shift in [('Null',-.10),('Interaction',0),('Row',.10)]:
            g=sel[(sel.model==model)&(sel.order==order)].sort_values('n')
            ax.plot(g.n,g.finite_target,color=COL[model],lw=1.25)
            ax.errorbar(g.n+shift,g['mean'],yerr=1.96*g.bias_mcse,color=COL[model],marker=MARK[model],
                        ls='none',ms=4,capsize=2)
            ax.axhline(g.limit.iloc[0],color=COL[model],ls=':',lw=1.15)
        ax.set(xticks=sorted(sel.n.unique()),xlabel='Terms per family, n',ylabel=f'Energy moment of order {order}')
        ax.set_title(f'{letter}   Order {order}',loc='left')
        ax.grid(axis='y')
        ax.yaxis.set_major_locator(MaxNLocator(5))
    handles=[Line2D([],[],color=COL[s],marker=MARK[s],label=s) for s in ['Null','Interaction','Row']]
    fig.legend(handles=handles,loc='upper center',ncol=3,frameon=False)
    save(fig,root,'03_untagged_moments')


def latex_table(root,name,caption,columns,rows):
    """Headers/cells are trusted local TeX strings. The generated fragments require booktabs."""
    align='l'+'r'*(len(columns)-1)
    lines=[r'\begin{table}[htbp]',r'\centering',r'\small',r'\caption{'+caption+'}',
           r'\label{tab:'+name+'}',r'\begin{tabular}{'+align+'}',r'\toprule',
           ' & '.join(columns)+r' \\',r'\midrule']
    lines+=[' & '.join(row)+r' \\' for row in rows]
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    (root/'tables'/(name+'.tex')).write_text('\n'.join(lines)+'\n')


def render(root,cfg,ref,shifts,couplings,C,molecule,network,traces,conditional):
    style()
    focus=cfg['network_sizes'][len(cfg['network_sizes'])//2]
    molecule_figure(root,shifts,couplings,C,molecule)
    network_figure(root,network,focus)
    trace_figure(root,traces)
    budget_figure(root,network,focus)
    rows=[]
    for a in molecule.itertuples():
        cov=f'{a.rate:.3f} ({a.rate_mcse:.3f})' if np.isfinite(a.rate) else '---'
        rows.append([str(a.T),a.method,f'{a.bias:.3g} ({a.bias_mcse:.2g})',f'{a.variance:.3g}',
                     f'{a.theory_variance:.3g}',cov])
    latex_table(root,'nmr_recovery',
                r'Molecular recovery over independent synthetic experiments. Parentheses give Monte Carlo standard errors. Coverage refers to the exact equal-tailed 95\% endpoint interval.',
                ['$T$','Estimator','Bias (MCSE)','Variance','Exact variance','Coverage (MCSE)'],rows)
    subset=network[(network.n==focus)&(network.budget_for=='Score')&(network.budget_ratio==1)]
    rows=[]
    for (m,model,d),g in subset.groupby(['m','model','delta'],sort=False):
        by=g.set_index('method')
        cells=[f'{m} $\\times$ {focus}',model,f'{d:g}',f'{int(g["T"].iloc[0]):,}']
        for method in METHODS[:2]:
            a=by.loc[method]
            cells.append(f'{a.rate:.3f} ({a.rate_mcse:.3f})')
        rows.append(cells)
    latex_table(root,'graphon_test',
                r'One-sided 5\% test on independent hidden arrays. Both estimators use identical energy records at $T=\mathrm{round}((360/41)L)$. Parentheses give Monte Carlo standard errors.',
                ['Array','Model',r'$\delta$','$T$','Endpoint','Score'],rows)
    rows=[]
    n=max(cfg['trace_sizes'])
    for a in traces[(traces.m==n)&(traces.n==n)&((traces.delta==0)|(traces.delta==.75))].itertuples():
        rows.append([a.model,str(a.order),f'{a.mean:.4f} ({a.bias_mcse:.4f})',f'{a.finite_target:.4f}',f'{a.limit:.4f}'])
    latex_table(root,'spectral_moments',
                f'Untagged energy moments for a {n}-by-{n} system. Alternative amplitude is 0.75. The empirical mean and its Monte Carlo standard error are computed across independent systems.',
                ['Model','Order','Empirical (MCSE)','Exact finite mean','Limit'],rows)
    fixed=conditional[(conditional.m==focus)&(conditional.n==focus)&
                      (conditional.budget_for=='Score')&(conditional.budget_ratio==1)]
    rows=[[a.model,f'{a.delta:g}',f'{a.U_C:.5f}',str(a.T),f'{a.rate:.3f} ({a.rate_mcse:.3f})',
           f'{a.exact_coverage:.4f}'] for a in fixed.itertuples()]
    latex_table(root,'fixed_array_coverage',
                f'Conditional coverage of the 95\\% endpoint interval on a fixed {focus}-by-{focus} array per model and amplitude. Each row uses {cfg["conditional_reps"]} independent repetitions. The final column sums the binomial mass over all counts whose intervals cover the realized rectangle mean.',
                ['Model',r'$\delta$',r'$U_C$','$T$','Coverage (MCSE)','Exact coverage'],rows)
    small=pd.read_csv(root/'tables/small_tagged.csv')
    rows=[[a.model,a.method,str(a.T),f'{a.bias:.3g} ({a.bias_mcse:.2g})',f'{a.rmse:.3g}'] for a in small.itertuples()]
    latex_table(root,'small_spectra','Direct small-array spectral experiment. Errors are relative to the realized distinct-rectangle average.',
                ['Model','Estimator','$T$','Bias (MCSE)','RMSE'],rows)


CAPTIONS = """# Figure captions

1. **Molecular calibration.** Left: each cell gives the sign for a shift operator and a coupled pair, identified by GISSMO proton atom IDs. XX and YY have the same cross sign, so each pair is shown once. Right: empirical RMSE (symbols and solid lines) and the exact square-root variance (dotted lines) at each fixed-system shot budget. Dotted and solid curves may overlap.
2. **Hidden-array inference.** Left: one-sided rejection probability under the null at nominal 5%. Right: power on the indicated array. Each point uses a fresh-system ensemble. Both estimators receive the same energies and absolute shot budget, T = round((360/41)L). Horizontal marker offsets are for legibility. Bars give 95% Wilson intervals for Monte Carlo rejection probabilities. The row and interaction alternatives are related by column-sign switching, so their population cycle signal and cycle-statistic law coincide at a given amplitude.
3. **Untagged spectral moments.** Balanced arrays under the null and two alternatives at amplitude 0.75. Symbols give empirical means across independent systems; bars are 1.96 Monte Carlo standard errors. Solid lines connect exact finite ensemble means at the simulated sizes. Dotted lines mark the graphon limits. Some theoretical curves coincide. The row-only kernel has nonzero row degrees; its eighth-order benchmark uses the full crossing formula.
4. **Shot budget and null variance.** Symbols give the empirical between-replication variance multiplied by the number L of distinct rectangles, for both shapes at the central n. Bars are 1.96 plug-in Monte Carlo standard errors. Curves give the exact variance using each array's L and the estimator-specific null constant v. The two theoretical curves nearly coincide. The horizontal dotted line marks the hidden-array variance after scaling. The vertical line marks T = vL. Horizontal symbol offsets distinguish the two shapes.
"""
